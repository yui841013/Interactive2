$(document).ready(function(){
    $(".letter,.bottom,.top,.rectangleleft,.rectangletop,.rectangleright,.rectanglebottom,.square,.lefttop,.Vleft,.Xleft").mouseenter(function(){
    $(".stick").css("background", "DodgerBlue");
    $(".rectangle1").css("background", "#FFD700");
    $(".grad1").css("background", "#FFD700");
    $(".grad2").css("background", "Tomato");
    $(".rectangle2").css("background", "Tomato");
    $(".rectangle4").css("background", "#FFD700");
    $(".rectangle5").css("background", "Tomato");
    $(".top").css("background", "Violet");
    $(".grad12").css("background", "#MediumSeaGreen");
    $(".grad5").css("background", "MediumSeaGreen");
    $(".grad6").css("background", "Tomato");
    $(".grad3").css("background", "DodgerBlue");
    $(".grad4").css("background", "#FFD700");
    $(".grad7").css("background", "#FFD700");
    $(".grad11").css("background", "#FFD700");
    $(".grad10").css("background", "Tomato");
    $(".grad9").css("background", "DodgerBlue");
    $(".tri8").css("background", "MediumSeaGreen");
    $(".bottom1").css("background", "MediumSeaGreen");
    $(".middle3").css("background", "DodgerBlue");
    $(".tri10").css("background", "DodgerBlue");
    $(".middle").css("background", "DodgerBlue");
    $(".middle6").css("background", "DodgerBlue");
    $(".leftrec2").css("background", "#FFD700");
    $(".left").css("background", "#FFD700");
    $(".right6").css("background", "#FFD700");
    $(".bottom").css("background", "MediumSeaGreen");
    $(".fourleft").css("background", "#FFD700");
    $(".fourright").css("background", "Tomato");
    $(".right").css("background", "Tomato");
    $(".grad11").css("background", "#FFD700");
    $(".grad12").css("background", "MediumSeaGreen");
    $(".right6").css("background", "Tomato");           














        
        //document.getElementById("grad1").style.color = "#c9d6d3" ;
        //$('.grad1').css({'background-image': 'linear-gradient(to bottom, #93d0aa , #6fa57e)'});

        
        // document.getElementById("grad1").style.backgroundColor ="linear-gradient(to bottom, #93d0aa , #6fa57e)";
      

    });
   

    $(".letter,.bottom,.top,.rectangleleft,.rectangletop,.rectangleright,.rectanglebottom").mouseleave(function(){
        $(".rectangle1").css("background", "#93d0aa");
        $(".stick").css("background", "#93d0aa");
        $(".top").css("background", "#93d0aa");
        $(".rectangle2").css("background", "#93d0aa");
        $(".rectangle4").css("background", "#93d0aa");
        $(".rectangle5").css("background", "#93d0aa");
        $(".tri8").css("background", "#93d0aa");
        $(".bottom1").css("background", "#93d0aa");
        $(".middle3").css("background", "#93d0aa");
        $(".middle6").css("background", "#93d0aa");
        $(".leftrec2").css("background", "#93d0aa");
        $(".right6").css("background", "#93d0aa");
        $(".right").css("background", "#93d0aa");
        $(".left").css("background", "#93d0aa");
        $(".bottom").css("background", "#93d0aa");
        $(".middle").css("background", "#93d0aa");
        $(".fourleft").css("background", "#93d0aa");
        $(".grad4").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad1").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
        $(".grad3").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
        $(".grad9").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e');
        $(".grad2").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".grad5").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
        $(".grad11").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".grad12").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e');
        $(".grad6").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad10").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".grad7").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".tri10").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');

        
        // $('.grad1').css({
        // 	'background-image': 'linear-gradient(to bottom, #ff0000 , #ffde00)',
        // 	'width': '10px'
        // });





    });
    
});


                // $('.grad1').css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e)');
