$(document).ready(function(){
    $(".letter,.bottom,.top,.rectangleleft,.rectangletop,.rectangleright,.rectanglebottom,.square,.lefttop,.Vleft,.Xleft").mouseenter(function(){
    $(".rectangleleft").css("background", "#FFD700");
    $(".rectangleright").css("background", "Tomato");
    $(".topleft").css("background", "#FFD700");
    $(".Btraiangle").css("background", "#FFD700");
    $(".btop").css("background", "Tomato");
           $(".bottomright").css("background", "MediumSeaGreen");
           $(".bmid").css("background", "DodgerBlue");
           $(".btri").css("border-top", "55px solid  Tomato");
           $(".bbottom").css("background", "Tomato");
           $(".bottomcurve").css("background", "Tomato");
           $(".topcurve").css("background", "Tomato");
           $(".rectangleright").css("background", "Tomato");
           $(".Dright").css("background", "Tomato");
           $(".rectangletop").css("background", "Violet");
           $(".middle").css("background", "DodgerBlue");
           $(".bottom").css("background", "MediumSeaGreen");
           $(".bottomleft").css("background", "MediumSeaGreen");
           $(".Gcurve").css("background", "Tomato");
           $(".gdian").css("background", "#FFD700");
           $(".triangle").css("background", "Tomato");
           $(".tricurve").css("background", "Tomato");
           $(".top").css("background", "Violet");
           $(".stick").css("background", "#FFD700");
           $(".square").css("background", "#FFD700");
           $(".krighttop").css("background", "Tomato");
           $(".kmiddle").css("background", "DodgerBlue");
           $(".ktri1").css("background", "Tomato");
           $(".krightbottom").css("background", "Tomato");
           $(".ktri2").css("background", "Tomato");
           $(".ML").css("background", "#FFD700");
           $(".MR").css("background", "Tomato");
           $(".M1").css("background", "DodgerBlue");
           $(".M2").css("background", "DodgerBlue");
           $(".m2grad").css("background", "DodgerBlue");
           $(".m2grad1").css("background", "DodgerBlue");
           $(".m2grad2").css("background", "DodgerBlue");
           $(".lefty").css("background", "#FFD700");
           $(".righty").css("background", "Tomato");
           $(".square2").css("background", "DodgerBlue");
           $(".diagonal").css("background", "DodgerBlue");
           $(".righthand").css("background", "Tomato");
           $(".N1").css("background", "Tomato");
           $(".Pright").css("background", "Tomato");
           $(".rmid").css("background", "DodgerBlue");
           $(".rstick").css("background", "Tomato");
           $(".lefttop").css("background", "#FFD700");
           $(".bottomleft").css("background", "MediumSeaGreen");
           $(".tri2").css("background", "Tomato");
           $(".trimiddle").css("background", "#FFD700");
           $(".rightdown").css("background", "Tomato");
           $(".Vleft").css("background", "#FFD700");
           $(".Vright").css("background", "Tomato");
           $(".square1").css("background", "#FFD700");
           $(".W").css("background", "#FFD700");
           $(".xleft").css("background", "#FFD700");
           $(".xright").css("background", "Tomato");
           $(".xgrad1").css("background", "#FFD700");
           $(".vgrad").css("background", "#FFD700");
           $(".xgrad2").css("background", "#FFD700");
           $(".grad1").css("background", "Violet");
           $(".grad2").css("background","Tomato");
           $(".grad3").css("background", "DodgerBlue");
           $(".grad4").css("background", "DodgerBlue"); 
           $(".grad5").css("background", "#FFD700");
           $(".grad6").css("background", "MediumSeaGreen");
           $(".grad7").css("background", "Violet");
           $(".grad10").css("background", "MediumSeaGreen");
           $(".grad11").css("background", "Tomato");
           $(".grad12").css("background", "#FFD700");
           $(".grad16").css("background", "#FFD700");
           $(".grad15").css("background", "#FFD700");
           $(".grad14").css("background", "#FFD700");
           $(".grad17").css("background", "#FFD700");
           $(".grad18").css("background", "Tomato");
           $(".grad19").css("background", "Tomato");
           $(".bottomgrad").css("background", "MediumSeaGreen");
           $(".topgrad").css("background", "Violet");
           $(".rgrad").css("background", "Tomato");
           $(".triQ").css("border-bottom", "50px solid MediumSeaGreen");














        
        //document.getElementById("grad1").style.color = "#c9d6d3" ;
        //$('.grad1').css({'background-image': 'linear-gradient(to bottom, #93d0aa , #6fa57e)'});

        
        // document.getElementById("grad1").style.backgroundColor ="linear-gradient(to bottom, #93d0aa , #6fa57e)";
      

    });
   

    $(".letter,.bottom,.top,.rectangleleft,.rectangletop,.rectangleright,.rectanglebottom").mouseleave(function(){
        $(".rectangleleft").css("background", "#93d0aa");
        $(".rectangleright").css("background", "#93d0aa");
        $(".topleft").css("background", "#93d0aa");
        $(".grad1").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e)');
        $(".grad2").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e)');
        $(".grad3").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e)');
        $(".grad4").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e)');
        $(".grad5").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e)');
        $(".grad6").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
        $(".grad7").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
        $(".grad10").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e');
        $(".grad11").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad16").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".grad15").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad12").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad14").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".grad17").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad18").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".grad19").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
        $(".xgrad2").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".xgrad1").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
        $(".rgrad").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');

        $(".Btraiangle").css("background", "#93d0aa");
        $(".bottomright").css("background", "#93d0aa");
        $(".btop").css("background", "#93d0aa");
        $(".bmid").css("background", "#93d0aa");
        $(".btri").css("border-top", "55px solid  #93d0aa");
        $(".bbottom").css("background", "#93d0aa");
        $(".bottomcurve").css("background", "#93d0aa");
        $(".topcurve").css("background", "#93d0aa");
        $(".rectangleright").css("background", "#93d0aa");
        $(".Dright").css("background", "#93d0aa");
        $(".rectangletop").css("background", "#93d0aa");
        $(".middle").css("background", "#93d0aa");
        $(".bottom").css("background", "#93d0aa");
        $(".bottomleft").css("background", "#93d0aa");
        $(".Gcurve").css("background", "#93d0aa");
        $(".diagonal").css("background", "#93d0aa");
           $(".gdian").css("background", "#93d0aa");
           $(".triangle").css("background", "#93d0aa");
           $(".tricurve").css("background", "#93d0aa");
           $(".top").css("background", "#93d0aa");
           $(".stick").css("background", "#93d0aa");
           $(".square").css("background", "#93d0aa");
           $(".krighttop").css("background", "#93d0aa");
           $(".kmiddle").css("background", "#93d0aa");
           $(".ktri1").css("background", "#93d0aa");
           $(".krightbottom").css("background", "#93d0aa");
           $(".ktri2").css("background", "#93d0aa");
           $(".ML").css("background", "#93d0aa");
           $(".MR").css("background", "#93d0aa");
           $(".M1").css("background", "#93d0aa");
           $(".M2").css("background", "#93d0aa");
           $(".lefty").css("background", "#93d0aa");
           $(".righty").css("background", "#93d0aa");
           $(".square2").css("background", "#93d0aa");
           $(".righthand").css("background", "#93d0aa");
           $(".righthand").css("background", "#93d0aa");
           $(".N1").css("background", "#93d0aa");
           $(".Pright").css("background", "#93d0aa");
           $(".rmid").css("background", "#93d0aa");
           $(".rstick").css("background", "#93d0aa");
           $(".lefttop").css("background", "#93d0aa");
           $(".bottomleft").css("background", "#93d0aa");
           $(".tri2").css("background", "#93d0aa");
           $(".trimiddle").css("background", "#93d0aa");
           $(".rightdown").css("background", "#93d0aa");
           $(".Vleft").css("background", "#93d0aa");
           $(".Vright").css("background", "#93d0aa");
           $(".square1").css("background", "#93d0aa");
           $(".W").css("background", "#93d0aa");
           $(".xleft").css("background", "#93d0aa");
           $(".xright").css("background", "#93d0aa");
           $(".triQ").css("border-bottom", "50px solid #93d0aa");
           $(".m2grad").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
           $(".m2grad1").css('background-image', 'linear-gradient(to top, #93d0aa , #6fa57e');
           $(".vgrad").css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e');
           $(".topgrad").css('background-image', 'linear-gradient(to right, #93d0aa , #6fa57e');
           $(".m2grad2").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e');
           $(".bottomgrad").css('background-image', 'linear-gradient(to left, #93d0aa , #6fa57e');

        
        // $('.grad1').css({
        // 	'background-image': 'linear-gradient(to bottom, #ff0000 , #ffde00)',
        // 	'width': '10px'
        // });





    });
    
});


                // $('.grad1').css('background-image', 'linear-gradient(to bottom, #93d0aa , #6fa57e)');
